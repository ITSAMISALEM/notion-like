import React from 'react';
import Editor from './components/Editor';
import { FileText } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b bg-white">
        <div className="max-w-5xl mx-auto px-4 py-3">
          <div className="flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-semibold">NotionLike</h1>
          </div>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="mb-8">
          <input
            type="text"
            placeholder="Untitled"
            className="text-3xl font-bold bg-transparent border-none outline-none w-full"
          />
        </div>
        <Editor />
      </main>
    </div>
  );
}

export default App;