import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

if (!API_KEY) {
  throw new Error('Missing Gemini API key');
}

const genAI = new GoogleGenerativeAI(API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

type StreamCallback = (chunk: string) => void;

async function generateContentStream(prompt: string, onChunk: StreamCallback): Promise<void> {
  try {
    const result = await model.generateContentStream(prompt);
    
    for await (const chunk of result.stream) {
      const text = chunk.text();
      if (text) {
        onChunk(text);
      }
    }
  } catch (error) {
    console.error('Gemini API Error:', error);
    throw new Error('Failed to generate content. Please try again.');
  }
}

export async function improveWriting(text: string, onChunk: StreamCallback): Promise<void> {
  if (!text.trim()) {
    throw new Error('Please provide some text to improve');
  }
  
  const prompt = `Please improve the following text to make it more clear, concise, and professional while maintaining its original meaning. If you find any grammar or spelling errors, fix those as well.

Text to improve:
"""
${text}
"""

Improved version:`;

  return generateContentStream(prompt, onChunk);
}

export async function continueWriting(text: string, onChunk: StreamCallback): Promise<void> {
  if (!text.trim()) {
    throw new Error('Please provide some text to continue');
  }

  const prompt = `Please continue the following text in a natural and coherent way, maintaining the same style and tone. Add 2-3 sentences that logically follow from the given text.

Original text:
"""
${text}
"""

Continuation:`;

  return generateContentStream(prompt, onChunk);
}

export async function generateOutline(text: string, onChunk: StreamCallback): Promise<void> {
  if (!text.trim()) {
    throw new Error('Please provide some text to outline');
  }

  const prompt = `Please create a detailed outline for the following text, organizing the main ideas and supporting points in a clear hierarchical structure.

Text to outline:
"""
${text}
"""

Outline:`;

  return generateContentStream(prompt, onChunk);
}

export async function fixGrammar(text: string, onChunk: StreamCallback): Promise<void> {
  if (!text.trim()) {
    throw new Error('Please provide some text to fix');
  }

  const prompt = `Please fix any grammar, spelling, or punctuation errors in the following text while preserving its original meaning. If the text is already correct, return it unchanged.

Text to fix:
"""
${text}
"""

Corrected version:`;

  return generateContentStream(prompt, onChunk);
}