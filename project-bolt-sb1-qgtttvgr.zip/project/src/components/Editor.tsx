import { useEditor, EditorContent, BubbleMenu } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import TaskList from '@tiptap/extension-task-list';
import TaskItem from '@tiptap/extension-task-item';
import Highlight from '@tiptap/extension-highlight';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import {
  Bold,
  Italic,
  List,
  Heading1,
  Heading2,
  Heading3,
  CheckSquare,
  Code,
  Quote,
  Highlighter,
  Text,
  ListOrdered,
  Wand2,
  ArrowRight,
  ListTree,
  Sparkles,
  Table as TableIcon,
  Plus,
  Search,
} from 'lucide-react';
import { useCallback, useEffect, useState, useRef } from 'react';
import { improveWriting, continueWriting, generateOutline, fixGrammar } from '../lib/gemini';

const SlashMenu = ({ editor, isOpen, onClose, position }: { 
  editor: any; 
  isOpen: boolean; 
  onClose: () => void;
  position: { x: number; y: number } | null;
}) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  const menuItems = [
    { icon: <Text className="w-4 h-4" />, title: 'Text', description: 'Just start writing with plain text', action: () => editor.chain().focus().setParagraph().run() },
    { icon: <Heading1 className="w-4 h-4" />, title: 'Heading 1', description: 'Big section heading', action: () => editor.chain().focus().toggleHeading({ level: 1 }).run() },
    { icon: <Heading2 className="w-4 h-4" />, title: 'Heading 2', description: 'Medium section heading', action: () => editor.chain().focus().toggleHeading({ level: 2 }).run() },
    { icon: <Heading3 className="w-4 h-4" />, title: 'Heading 3', description: 'Small section heading', action: () => editor.chain().focus().toggleHeading({ level: 3 }).run() },
    { icon: <List className="w-4 h-4" />, title: 'Bullet List', description: 'Create a simple bullet list', action: () => editor.chain().focus().toggleBulletList().run() },
    { icon: <ListOrdered className="w-4 h-4" />, title: 'Numbered List', description: 'Create a numbered list', action: () => editor.chain().focus().toggleOrderedList().run() },
    { icon: <CheckSquare className="w-4 h-4" />, title: 'To-do List', description: 'Track tasks with a to-do list', action: () => editor.chain().focus().toggleTaskList().run() },
    { icon: <Quote className="w-4 h-4" />, title: 'Quote', description: 'Capture a quote', action: () => editor.chain().focus().toggleBlockquote().run() },
    { icon: <Code className="w-4 h-4" />, title: 'Code', description: 'Capture a code snippet', action: () => editor.chain().focus().toggleCodeBlock().run() },
    { 
      icon: <TableIcon className="w-4 h-4" />, 
      title: 'Table', 
      description: 'Add a table', 
      action: () => editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run() 
    },
  ];

  const filteredItems = menuItems.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex((i) => (i + 1) % filteredItems.length);
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex((i) => (i - 1 + filteredItems.length) % filteredItems.length);
          break;
        case 'Enter':
          e.preventDefault();
          if (filteredItems[selectedIndex]) {
            filteredItems[selectedIndex].action();
            onClose();
          }
          break;
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, filteredItems, onClose]);

  if (!isOpen || !position) return null;

  return (
    <div 
      className="fixed z-50 w-80 bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden"
      style={{ 
        top: position.y + 24,
        left: position.x
      }}
    >
      <div className="p-2">
        <div className="relative mb-2">
          <input
            ref={searchInputRef}
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Search for blocks..."
            className="w-full px-8 py-2 bg-gray-50 border border-gray-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-gray-400" />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-2 top-2 p-0.5 rounded-full hover:bg-gray-200"
            >
              <Plus className="w-4 h-4 text-gray-400 rotate-45" />
            </button>
          )}
        </div>
        <div className="space-y-0.5 max-h-80 overflow-y-auto">
          {filteredItems.map((item, index) => (
            <button
              key={item.title}
              className={`w-full flex items-start gap-3 px-3 py-2 rounded-md text-left transition-colors ${
                index === selectedIndex ? 'bg-gray-100' : 'hover:bg-gray-50'
              }`}
              onClick={() => {
                item.action();
                onClose();
              }}
              onMouseEnter={() => setSelectedIndex(index)}
            >
              <div className="mt-1 text-gray-600">{item.icon}</div>
              <div>
                <div className="font-medium">{item.title}</div>
                <div className="text-xs text-gray-500">{item.description}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

const SelectionMenu = ({ editor }: { editor: any }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAIAction = async (
    action: (text: string, onChunk: (chunk: string) => void) => Promise<void>
  ) => {
    const selectedText = editor?.state.doc.textBetween(
      editor.state.selection.from,
      editor.state.selection.to,
      ' '
    );

    if (!selectedText) {
      setError('Please select some text first');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const from = editor.state.selection.from;
      const to = editor.state.selection.to;

      editor.chain().focus().setTextSelection({ from, to }).deleteSelection().run();
      
      let accumulatedText = '';

      await action(selectedText, (chunk) => {
        accumulatedText += chunk;
        editor
          .chain()
          .focus()
          .setTextSelection({ from, to: from })
          .insertContent(chunk)
          .run();
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to process text';
      setError(message);
      console.error('AI action failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!editor) return null;

  return (
    <BubbleMenu
      className="flex overflow-hidden bg-white rounded-lg shadow-lg border border-gray-200"
      tippyOptions={{ duration: 100 }}
      editor={editor}
    >
      <div className="flex items-center divide-x divide-gray-200">
        <div className="flex">
          <button
            onClick={() => editor.chain().focus().toggleBold().run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('bold') ? 'bg-gray-100' : ''}`}
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            onClick={() => editor.chain().focus().toggleItalic().run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('italic') ? 'bg-gray-100' : ''}`}
          >
            <Italic className="w-4 h-4" />
          </button>
          <button
            onClick={() => editor.chain().focus().toggleHighlight().run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('highlight') ? 'bg-gray-100' : ''}`}
          >
            <Highlighter className="w-4 h-4" />
          </button>
          <button
            onClick={() => editor.chain().focus().toggleCode().run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('code') ? 'bg-gray-100' : ''}`}
          >
            <Code className="w-4 h-4" />
          </button>
        </div>

        <div className="flex">
          <button
            onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('heading', { level: 1 }) ? 'bg-gray-100' : ''}`}
          >
            <Heading1 className="w-4 h-4" />
          </button>
          <button
            onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('heading', { level: 2 }) ? 'bg-gray-100' : ''}`}
          >
            <Heading2 className="w-4 h-4" />
          </button>
        </div>

        <div className="flex">
          <button
            onClick={() => editor.chain().focus().toggleBulletList().run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('bulletList') ? 'bg-gray-100' : ''}`}
          >
            <List className="w-4 h-4" />
          </button>
          <button
            onClick={() => editor.chain().focus().toggleTaskList().run()}
            className={`p-2 hover:bg-gray-100 ${editor.isActive('taskList') ? 'bg-gray-100' : ''}`}
          >
            <CheckSquare className="w-4 h-4" />
          </button>
        </div>

        <div className="flex">
          <button
            onClick={() => handleAIAction(improveWriting)}
            disabled={isLoading}
            className="p-2 hover:bg-gray-100 disabled:opacity-50"
            title="Improve writing"
          >
            <Wand2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleAIAction(continueWriting)}
            disabled={isLoading}
            className="p-2 hover:bg-gray-100 disabled:opacity-50"
            title="Continue writing"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleAIAction(generateOutline)}
            disabled={isLoading}
            className="p-2 hover:bg-gray-100 disabled:opacity-50"
            title="Generate outline"
          >
            <ListTree className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleAIAction(fixGrammar)}
            disabled={isLoading}
            className="p-2 hover:bg-gray-100 disabled:opacity-50"
            title="Fix grammar"
          >
            <Sparkles className="w-4 h-4" />
          </button>
        </div>
      </div>
      {isLoading && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white p-2 rounded-lg shadow-lg border border-gray-200 text-sm text-gray-500">
          Generating...
        </div>
      )}
      {error && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-red-50 p-2 rounded-lg shadow-lg border border-red-100 text-sm text-red-600">
          {error}
        </div>
      )}
    </BubbleMenu>
  );
};

export default function Editor() {
  const [slashMenuOpen, setSlashMenuOpen] = useState(false);
  const [menuPosition, setMenuPosition] = useState<{ x: number; y: number } | null>(null);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: 'Type / for commands...',
      }),
      TaskList,
      TaskItem.configure({
        nested: true,
      }),
      Highlight,
      Table.configure({
        resizable: true,
      }),
      TableRow,
      TableHeader,
      TableCell,
    ],
    content: '',
    editorProps: {
      attributes: {
        class: 'prose prose-gray max-w-none focus:outline-none min-h-[300px]',
      },
    },
  });

  const handleSlashCommand = useCallback((e: KeyboardEvent) => {
    if (e.key === '/' && !slashMenuOpen) {
      e.preventDefault();
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        setMenuPosition({
          x: rect.left,
          y: rect.top
        });
        setSlashMenuOpen(true);
      }
    }
  }, [slashMenuOpen]);

  useEffect(() => {
    if (!editor) return;

    const editorElement = editor.view.dom;
    editorElement.addEventListener('keydown', handleSlashCommand);
    
    return () => {
      editorElement.removeEventListener('keydown', handleSlashCommand);
    };
  }, [editor, handleSlashCommand]);

  return (
    <div className="min-h-[500px] bg-white rounded-lg shadow-sm border border-gray-200">
      {editor && (
        <>
          <SelectionMenu editor={editor} />
          <SlashMenu 
            editor={editor}
            isOpen={slashMenuOpen}
            onClose={() => setSlashMenuOpen(false)}
            position={menuPosition}
          />
        </>
      )}
      <EditorContent editor={editor} className="p-4" />
    </div>
  );
}