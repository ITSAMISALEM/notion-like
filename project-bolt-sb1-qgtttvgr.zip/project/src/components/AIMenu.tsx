import React from 'react';
import { Wand2, ArrowRight, ListTree, Sparkles } from 'lucide-react';
import { improveWriting, continueWriting, generateOutline, fixGrammar } from '../lib/gemini';

interface AIMenuProps {
  editor: any;
}

export default function AIMenu({ editor }: AIMenuProps) {
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const getSelectedText = () => {
    return editor?.state.doc.textBetween(
      editor.state.selection.from,
      editor.state.selection.to,
      ' '
    );
  };

  const handleAIAction = async (
    action: (text: string, onChunk: (chunk: string) => void) => Promise<void>
  ) => {
    const selectedText = getSelectedText();
    if (!selectedText) {
      setError('Please select some text first');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Store the selection range
      const from = editor.state.selection.from;
      const to = editor.state.selection.to;

      // Clear the selected text
      editor.chain().focus().setTextSelection({ from, to }).deleteSelection().run();
      
      let accumulatedText = '';

      await action(selectedText, (chunk) => {
        accumulatedText += chunk;
        editor
          .chain()
          .focus()
          .setTextSelection({ from, to: from })
          .insertContent(chunk)
          .run();
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to process text';
      setError(message);
      console.error('AI action failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="border-t border-gray-200 bg-white">
      <div className="flex gap-1 items-center p-2">
        <button
          onClick={() => handleAIAction(improveWriting)}
          disabled={isLoading}
          className="flex items-center gap-1 px-3 py-1 rounded hover:bg-gray-100 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Wand2 className="w-4 h-4" />
          Improve
        </button>
        <button
          onClick={() => handleAIAction(continueWriting)}
          disabled={isLoading}
          className="flex items-center gap-1 px-3 py-1 rounded hover:bg-gray-100 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ArrowRight className="w-4 h-4" />
          Continue
        </button>
        <button
          onClick={() => handleAIAction(generateOutline)}
          disabled={isLoading}
          className="flex items-center gap-1 px-3 py-1 rounded hover:bg-gray-100 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ListTree className="w-4 h-4" />
          Outline
        </button>
        <button
          onClick={() => handleAIAction(fixGrammar)}
          disabled={isLoading}
          className="flex items-center gap-1 px-3 py-1 rounded hover:bg-gray-100 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Sparkles className="w-4 h-4" />
          Fix Grammar
        </button>
        {isLoading && (
          <span className="text-sm text-gray-500 ml-2">Generating...</span>
        )}
      </div>
      {error && (
        <div className="px-4 py-2 bg-red-50 border-t border-red-100 text-red-600 text-sm">
          {error}
        </div>
      )}
    </div>
  );
}